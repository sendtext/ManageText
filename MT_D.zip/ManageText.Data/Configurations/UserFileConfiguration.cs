﻿using ManageText.Entities.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Data.Configurations
{
   public class UserFileConfiguration : EntityBaseConfiguration<UserFile>
    {
        public UserFileConfiguration()
        {
            Property(ur => ur.UserId).IsRequired();
            Property(ur => ur.FileId).IsRequired();
        }
    }
}
