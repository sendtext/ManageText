﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

namespace ManageText.Web.App_Start
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                "~/Scripts/Vendors/modernizr.js"));

            bundles.Add(new ScriptBundle("~/bundles/vendors").Include(
               "~/Scripts/jquery-2.2.4.js",
               "~/Scripts/bootstrap.js",
               "~/Scripts/toastr.js",
               //"~/Scripts/Vendors/jquery.raty.js",
               "~/Scripts/respond.js",
               "~/Scripts/angular.js",
               //"~/Scripts/angular-route.js",
               "~/Scripts/ui-router.js",
               "~/Scripts/angular-animate.js",
               "~/Scripts/angular-messages.js",
               "~/Scripts/angular-sanitize.js",
               "~/Scripts/angular-resource.js",
               "~/Scripts/angular-cookies.js",
               "~/Scripts/angular-validator.js",
               "~/Scripts/angular-base64.js",
               "~/Scripts/angular-file-upload.js",
                "~/Scripts/Vendors/angucomplete-alt.js",
               "~/Scripts/Vendors/ui-bootstrap-tpls-2.5.0.js",
               "~/Scripts/Vendors/underscore-min.js",
               "~/Scripts/raphael-min.js",
               "~/Scripts/Vendors/morris.min.js",
               "~/Scripts/Vendors/jquery.fancybox.js",
               "~/Scripts/Vendors/jquery.fancybox-media.js",
               "~/Scripts/loading-bar.js"
               ));

            bundles.Add(new ScriptBundle("~/bundles/spa").Include(
                "~/Scripts/spa/modules/common.core.js",
                "~/Scripts/spa/modules/common.ui.js",
                "~/Scripts/spa/app.js",
                "~/Scripts/spa/services/apiService.js",
                "~/Scripts/spa/services/notificationService.js",
                "~/Scripts/spa/services/membershipService.js",
                "~/Scripts/spa/account/loginCtrl.js",
                "~/Scripts/spa/account/registerCtrl.js",
                "~/Scripts/spa/home/rootCtrl.js",
                "~/Scripts/spa/home/indexCtrl.js"




                ));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                //"~/content/css/site.css",
                "~/content/css/bootstrap.min.css",
                "~/content/css/bootstrap-theme.min.css",
                 "~/content/css/font-awesome.css",
                 
                "~/content/css/morris.min.css",
                "~/content/css/toastr.min.css",
                "~/content/css/jquery.fancybox.css",
                "~/content/css/style.css",
               "~/content/css/bootsnip.css",
                "~/content/css/loading-bar.min.css"));



            //bundles.Add(new ScriptBundle("~/bundles/vendors").Include(
            //    "~/Scripts/Vendors/jquery-2.2.4.min.js",
            //    "~/Scripts/Vendors/bootstrap.min.js",
            //    "~/Scripts/Vendors/toastr.min.js",
            //    //"~/Scripts/Vendors/jquery.raty.js",
            //    "~/Scripts/Vendors/respond.min.js",
            //    "~/Scripts/Vendors/angular.min.js",
            //    //"~/Scripts/Vendors/angular-route.js",
            //    "~/Scripts/Vendors/ui-router.min.js",
            //    "~/Scripts/Vendors/angular-animate.min.js",
            //    "~/Scripts/Vendors/angular-messages.min.js",
            //    "~/Scripts/Vendors/angular-sanitize.min.js",              
            //    "~/Scripts/Vendors/angular-resource.min.js",
            //    "~/Scripts/Vendors/angular-cookies.min.js",
            //    "~/Scripts/Vendors/angular-validator.min.js",
            //    "~/Scripts/Vendors/angular-base64.min.js",
            //    "~/Scripts/Vendors/angular-file-upload.min.js",
            //    "~/Scripts/Vendors/ui-bootstrap-tpls-2.5.0.js",
            //    "~/Scripts/Vendors/underscore-min.js",
            //    "~/Scripts/Vendors/raphael-min.js",
            //    "~/Scripts/Vendors/morris.min.js",
            //    "~/Scripts/Vendors/jquery.fancybox.js",
            //    "~/Scripts/Vendors/jquery.fancybox-media.js",
            //    "~/Scripts/Vendors/loading-bar.min.js"
            //    ));


            BundleTable.EnableOptimizations = false;
        }
    }
}