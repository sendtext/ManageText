﻿using AutoMapper;
using ManageText.Entities.Account;
using ManageText.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ManageText.Web.Mappings
{

    public class ViewModelToDomainMappingProfile : Profile
    {

        public override string ProfileName
        {
            get { return "ViewModelToDomainMappings"; }
        }


        protected ViewModelToDomainMappingProfile()
        {
            CreateMap<RegisterViewModel,User>();

        }
    }
}