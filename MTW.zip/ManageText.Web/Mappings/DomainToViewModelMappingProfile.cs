﻿using AutoMapper;
using ManageText.Entities.Account;
using ManageText.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ManageText.Web.Mappings
{

   public class DomainToViewModelMappingProfile : Profile
   {

        public override string ProfileName
        {
            get { return "DomainToViewModelMappings"; }
        }

        public DomainToViewModelMappingProfile()
        {
            CreateMap<User, RegisterViewModel>();

        }
    }
}