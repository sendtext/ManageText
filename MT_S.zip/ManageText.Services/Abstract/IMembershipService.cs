﻿using ManageText.Entities.Account;
using ManageText.Services.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Services.Abstract
{
    public interface IMembershipService
    {
        MembershipContext ValidateUser(string username, string password);
        //User CreateUser(string username, string email, string password, int[] roles);    

        User CreateUser(User createuser, string password, int[] roles);
        List<Role> GetUserRoles(string username);

        //  User UpdateUser(string username, string email, string password, int[] roles);
        User GetUser(string username);

        //Added by Abu
       // User UpdateUserEdit(string username, bool Islocked);
    }
}
