﻿using ManageText.Entities.Account;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Entities.Payment
{
    public class StripeAccount : IEntityBase
    {
        public int ID { get; set; }

        [Display(Name = "Live Mode")]
        public bool LiveMode { get; set; }

        [Display(Name = "Live public API Key")]
        public string StripeLivePublicApiKey { get; set; }
        [Display(Name = "Live secret API Key")]
        public string StripeLiveSecretApiKey { get; set; }

        [Display(Name = "Test public API Key")]
        public string StripeTestPublicApiKey { get; set; }
        [Display(Name = "Test secret API Key")]
        public string StripeTestSecretApiKey { get; set; }

        public virtual User ManageTextUser { get; set; }
    }
}
