﻿using ManageText.Entities.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Entities.Common
{
    public  class Address : IEntityBase, IAuditable
    {

        public int ID { get; set; }


        public string AddressDetails { get; set; }
        public string StreetName { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Country { get; set; }


        //Relationship
        // public User User { get; set; }
        //  Company Id details 
        public int CompanyId { get; set; }
        public virtual Company Company { get; set; }


        //Audit Columns
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }

    }
}
