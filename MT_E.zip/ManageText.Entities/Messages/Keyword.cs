﻿using ManageText.Entities.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Entities.Messages
{
    public class Keyword : IEntityBase, IAuditable
    {

        public Keyword()
        {
            Files = new List<File>();
            Subscribers = new List<Subscriber>();
        }




        public int ID { get; set; }


        public string Name { get; set; }

        public bool Approved { get; set; }
        public DateTime? ApprovedDate{ get; set; }
        public string ApproveddBy { get; set; }

        public string OptIn { get; set; }
        public string OptOut { get; set; }
        public string TermsUrl { get; set; }

        public string DisplayMessage { get; set; }
        public string DisplayMessageCustomed { get; set; }

        public virtual ICollection<File> Files { get; set; }
        public virtual ICollection<Subscriber> Subscribers { get; set; }



        //  Customer Id details 
        //public int UserId { get; set; }
        //public virtual User User { get; set; }

        //  Company Id details 
        public int CompanyId { get; set; }
        public virtual Company Company { get; set; }


        //Audit Columumns
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }


    }
}
