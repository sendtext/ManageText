﻿using ManageText.Entities.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Entities.Messages
{
    public class Message : IEntityBase, IAuditable
    {

        public Message()
        {
            Files = new List<File>();
        }

        public int ID { get; set; }


        public string AccountSid { get; set; }
        public string ApiVersion { get; set; }

        //Message 160
        public string Body { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateSent { get; set; }
        public DateTime? DateUpdated { get; set; }
        //Twilio.Rest.Api.V2010.Account.MessageResource.DirectionEnum
        public string Direction { get; set; }
        public int? ErrorCode { get; set; }
        public string ErrorMessage { get; set; }

        public string From { get; set; }
        public string To { get; set; }

        public string MessagingServiceSid { get; set; }
        public string NumMedia { get; set; }
        public string NumSegments { get; set; }

        public decimal? Price { get; set; }
        public string PriceUnit { get; set; }
        public string Sid { get; set; }
        //Twilio.Rest.Api.V2010.Account.MessageResource.StatusEnum
        public string Status { get; set; }

        //System.Collections.Generic.Dictionary<string, string>
        public string SubresourceUris { get; set; }
        public string Uri { get; set; }

        public string TwilioStatus { get; set; }
        public string TwilioResponse { get; set; }


        public int KeywordId { get; set; }
        public virtual Keyword Keyword { get; set; }

        public int SubscriberId { get; set; }
        public virtual Subscriber Subscriber { get; set; }

        //public int CampaignId { get; set; }
        //public virtual Campaign Campaign { get; set; }




        public virtual ICollection<File> Files { get; set; }




        ////  Customer Id details 
        //public int UserId { get; set; }
        //public virtual User User { get; set; }


        //  Company Id details 
        public int CompanyId { get; set; }
        public virtual Company Company { get; set; }


        //Audit Columns
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }

    }
}
