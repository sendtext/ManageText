namespace ManageText.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initial_migration : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Address",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        AddressDetails = c.String(),
                        StreetName = c.String(),
                        City = c.String(),
                        State = c.String(),
                        Zip = c.String(),
                        Country = c.String(),
                        CreatedDate = c.DateTime(),
                        CreatedBy = c.String(maxLength: 50),
                        UpdatedDate = c.DateTime(),
                        UpdatedBy = c.String(maxLength: 50),
                        User_ID = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.User", t => t.User_ID)
                .Index(t => t.User_ID);
            
            CreateTable(
                "dbo.User",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        FirstName = c.String(nullable: false, maxLength: 100),
                        LastName = c.String(nullable: false, maxLength: 100),
                        CompanyName = c.String(nullable: false, maxLength: 1000),
                        PhoneNumber = c.String(nullable: false, maxLength: 100),
                        Email = c.String(nullable: false, maxLength: 200),
                        Comments = c.String(),
                        Description = c.String(nullable: false, maxLength: 1000),
                        HashedPassword = c.String(nullable: false, maxLength: 200),
                        Salt = c.String(nullable: false, maxLength: 200),
                        IsLocked = c.Boolean(nullable: false),
                        DateCreated = c.DateTime(nullable: false),
                        RegistrationDate = c.DateTime(),
                        LastLoginTime = c.DateTime(),
                        StripeCustomerId = c.String(),
                        IPAddress = c.String(),
                        IPAddressCountry = c.String(),
                        Delinquent = c.Boolean(nullable: false),
                        LifetimeValue = c.Decimal(precision: 18, scale: 2),
                        PhoneNumberConfirmed = c.Boolean(),
                        EmailConfirmed = c.Boolean(),
                        TwoFactorEnabled = c.Boolean(),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.CreditCard",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        StripeId = c.String(),
                        Name = c.String(nullable: false),
                        Last4 = c.String(),
                        Type = c.String(),
                        Fingerprint = c.String(),
                        AddressCity = c.String(nullable: false),
                        AddressCountry = c.String(nullable: false),
                        AddressLine1 = c.String(nullable: false),
                        AddressLine2 = c.String(),
                        AddressState = c.String(),
                        AddressZip = c.String(nullable: false),
                        Cvc = c.String(nullable: false, maxLength: 4),
                        ExpirationMonth = c.String(nullable: false),
                        ExpirationYear = c.String(nullable: false),
                        CardCountry = c.String(),
                        SaasEcomUserId = c.String(),
                        User_ID = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.User", t => t.User_ID)
                .Index(t => t.User_ID);
            
            CreateTable(
                "dbo.File",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Path = c.String(),
                        Name = c.String(),
                        Type = c.String(),
                        MIME = c.String(),
                        UserId = c.Int(nullable: false),
                        CreatedDate = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedDate = c.DateTime(),
                        UpdatedBy = c.String(),
                        Keyword_ID = c.Int(),
                        Message_ID = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.User", t => t.UserId, cascadeDelete: true)
                .ForeignKey("dbo.Keyword", t => t.Keyword_ID)
                .ForeignKey("dbo.Message", t => t.Message_ID)
                .Index(t => t.UserId)
                .Index(t => t.Keyword_ID)
                .Index(t => t.Message_ID);
            
            CreateTable(
                "dbo.Invoice",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        StripeId = c.String(maxLength: 50),
                        StripeCustomerId = c.String(maxLength: 50),
                        Date = c.DateTime(),
                        PeriodStart = c.DateTime(),
                        PeriodEnd = c.DateTime(),
                        Subtotal = c.Int(),
                        Total = c.Int(),
                        Attempted = c.Boolean(),
                        Closed = c.Boolean(),
                        Paid = c.Boolean(),
                        AttemptCount = c.Int(),
                        AmountDue = c.Int(),
                        StartingBalance = c.Int(),
                        EndingBalance = c.Int(),
                        NextPaymentAttempt = c.DateTime(),
                        ApplicationFee = c.Int(),
                        Tax = c.Int(),
                        TaxPercent = c.Decimal(precision: 18, scale: 2),
                        Currency = c.String(),
                        Description = c.String(),
                        StatementDescriptor = c.String(),
                        ReceiptNumber = c.String(),
                        Forgiven = c.Boolean(),
                        Customer_ID = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.User", t => t.Customer_ID)
                .Index(t => t.StripeId, unique: true)
                .Index(t => t.StripeCustomerId)
                .Index(t => t.Paid)
                .Index(t => t.Customer_ID);
            
            CreateTable(
                "dbo.LineItem",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        StripeLineItemId = c.String(),
                        Type = c.String(),
                        Amount = c.Int(),
                        Currency = c.String(),
                        Proration = c.Boolean(nullable: false),
                        Period_Start = c.DateTime(),
                        Period_End = c.DateTime(),
                        Quantity = c.Int(),
                        Plan_StripePlanId = c.String(),
                        Plan_Interval = c.String(),
                        Plan_Name = c.String(),
                        Plan_Created = c.DateTime(),
                        Plan_AmountInCents = c.Int(),
                        Plan_Currency = c.String(),
                        Plan_IntervalCount = c.Int(nullable: false),
                        Plan_TrialPeriodDays = c.Int(),
                        Plan_StatementDescriptor = c.String(),
                        Invoice_ID = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Invoice", t => t.Invoice_ID)
                .Index(t => t.Invoice_ID);
            
            CreateTable(
                "dbo.UserRole",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        UserId = c.Int(nullable: false),
                        RoleId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Role", t => t.RoleId, cascadeDelete: true)
                .ForeignKey("dbo.User", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId)
                .Index(t => t.RoleId);
            
            CreateTable(
                "dbo.Role",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 50),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Subscriber",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        PhoneNumber = c.String(),
                        FirstName = c.String(),
                        LastName = c.String(),
                        Email = c.String(),
                        AddressDetails = c.String(),
                        StreetName = c.String(),
                        City = c.String(),
                        State = c.String(),
                        Zip = c.String(),
                        Country = c.String(),
                        CompanyName = c.String(),
                        Comments = c.String(),
                        Subscribed = c.Boolean(nullable: false),
                        SubscribedAt = c.DateTime(nullable: false),
                        Disabled = c.Boolean(nullable: false),
                        DisabledAt = c.DateTime(nullable: false),
                        UserId = c.Int(nullable: false),
                        CreatedDate = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedDate = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.User", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.Keyword",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 100),
                        Approved = c.Boolean(nullable: false),
                        ApprovedDate = c.DateTime(),
                        ApproveddBy = c.String(),
                        OptIn = c.String(),
                        OptOut = c.String(),
                        TermsUrl = c.String(),
                        DisplayMessage = c.String(),
                        DisplayMessageCustomed = c.String(),
                        UserId = c.Int(nullable: false),
                        CreatedDate = c.DateTime(),
                        CreatedBy = c.String(maxLength: 50),
                        UpdatedDate = c.DateTime(),
                        UpdatedBy = c.String(maxLength: 50),
                        Campaign_ID = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.User", t => t.UserId, cascadeDelete: true)
                .ForeignKey("dbo.Campaign", t => t.Campaign_ID)
                .Index(t => t.UserId)
                .Index(t => t.Campaign_ID);
            
            CreateTable(
                "dbo.Subscription",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Start = c.DateTime(),
                        End = c.DateTime(),
                        TrialStart = c.DateTime(),
                        TrialEnd = c.DateTime(),
                        SubscriptionPlanId = c.String(),
                        UserId = c.String(),
                        StripeId = c.String(maxLength: 50),
                        Status = c.String(),
                        TaxPercent = c.Decimal(nullable: false, precision: 18, scale: 2),
                        ReasonToCancel = c.String(),
                        SubscriptionPlan_ID = c.Int(),
                        User_ID = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.SubscriptionPlan", t => t.SubscriptionPlan_ID)
                .ForeignKey("dbo.User", t => t.User_ID)
                .Index(t => t.StripeId)
                .Index(t => t.SubscriptionPlan_ID)
                .Index(t => t.User_ID);
            
            CreateTable(
                "dbo.SubscriptionPlan",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Plan_Id = c.String(nullable: false),
                        Name = c.String(nullable: false),
                        Price = c.Double(nullable: false),
                        Currency = c.String(),
                        Interval = c.Int(nullable: false),
                        TrialPeriodInDays = c.Int(nullable: false),
                        Disabled = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.SubscriptionPlanProperty",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Key = c.String(),
                        Value = c.String(),
                        SubscriptionPlan_ID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.SubscriptionPlan", t => t.SubscriptionPlan_ID, cascadeDelete: true)
                .Index(t => t.SubscriptionPlan_ID);
            
            CreateTable(
                "dbo.Campaign",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 1000),
                        Comments = c.String(maxLength: 1000),
                        Message = c.String(nullable: false),
                        MessageTypeId = c.Int(nullable: false),
                        FileId = c.Int(),
                        Schedule = c.Boolean(nullable: false),
                        ScheduledAt = c.DateTime(),
                        UserId = c.Int(nullable: false),
                        CreatedDate = c.DateTime(),
                        CreatedBy = c.String(maxLength: 50),
                        UpdatedDate = c.DateTime(),
                        UpdatedBy = c.String(maxLength: 50),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.File", t => t.FileId)
                .ForeignKey("dbo.MessageType", t => t.MessageTypeId, cascadeDelete: true)
                .ForeignKey("dbo.User", t => t.UserId, cascadeDelete: true)
                .Index(t => t.MessageTypeId)
                .Index(t => t.FileId)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.Message",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        AccountSid = c.String(),
                        ApiVersion = c.String(),
                        Body = c.String(),
                        DateCreated = c.DateTime(),
                        DateSent = c.DateTime(),
                        DateUpdated = c.DateTime(),
                        Direction = c.String(),
                        ErrorCode = c.Int(),
                        ErrorMessage = c.String(),
                        From = c.String(),
                        To = c.String(),
                        MessagingServiceSid = c.String(),
                        NumMedia = c.String(),
                        NumSegments = c.String(),
                        Price = c.Decimal(precision: 18, scale: 2),
                        PriceUnit = c.String(),
                        Sid = c.String(),
                        Status = c.String(),
                        SubresourceUris = c.String(),
                        Uri = c.String(),
                        TwilioStatus = c.String(),
                        TwilioResponse = c.String(),
                        KeywordId = c.Int(nullable: false),
                        SubscriberId = c.Int(nullable: false),
                        CampaignId = c.Int(nullable: false),
                        UserId = c.Int(nullable: false),
                        CreatedDate = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedDate = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Campaign", t => t.CampaignId, cascadeDelete: true)
                .ForeignKey("dbo.Keyword", t => t.KeywordId, cascadeDelete: false)
                .ForeignKey("dbo.Subscriber", t => t.SubscriberId, cascadeDelete: false)
                .ForeignKey("dbo.User", t => t.UserId, cascadeDelete: false)
                .Index(t => t.KeywordId)
                .Index(t => t.SubscriberId)
                .Index(t => t.CampaignId)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.MessageType",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Error",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        Message = c.String(),
                        StackTrace = c.String(),
                        DateCreated = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.StripeAccount",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        LiveMode = c.Boolean(nullable: false),
                        StripeLivePublicApiKey = c.String(),
                        StripeLiveSecretApiKey = c.String(),
                        StripeTestPublicApiKey = c.String(),
                        StripeTestSecretApiKey = c.String(),
                        ManageTextUser_ID = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.User", t => t.ManageTextUser_ID)
                .Index(t => t.ManageTextUser_ID);
            
            CreateTable(
                "dbo.UserFile",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        UserId = c.Int(nullable: false),
                        FileId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.File", t => t.FileId, cascadeDelete: true)
                .Index(t => t.FileId);
            
            CreateTable(
                "dbo.KeywordSubscriber",
                c => new
                    {
                        Keyword_ID = c.Int(nullable: false),
                        Subscriber_ID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Keyword_ID, t.Subscriber_ID })
                .ForeignKey("dbo.Keyword", t => t.Keyword_ID, cascadeDelete: true)
                .ForeignKey("dbo.Subscriber", t => t.Subscriber_ID, cascadeDelete: false)
                .Index(t => t.Keyword_ID)
                .Index(t => t.Subscriber_ID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.UserFile", "FileId", "dbo.File");
            DropForeignKey("dbo.StripeAccount", "ManageTextUser_ID", "dbo.User");
            DropForeignKey("dbo.Campaign", "UserId", "dbo.User");
            DropForeignKey("dbo.Campaign", "MessageTypeId", "dbo.MessageType");
            DropForeignKey("dbo.Message", "UserId", "dbo.User");
            DropForeignKey("dbo.Message", "SubscriberId", "dbo.Subscriber");
            DropForeignKey("dbo.Message", "KeywordId", "dbo.Keyword");
            DropForeignKey("dbo.File", "Message_ID", "dbo.Message");
            DropForeignKey("dbo.Message", "CampaignId", "dbo.Campaign");
            DropForeignKey("dbo.Keyword", "Campaign_ID", "dbo.Campaign");
            DropForeignKey("dbo.Campaign", "FileId", "dbo.File");
            DropForeignKey("dbo.Subscription", "User_ID", "dbo.User");
            DropForeignKey("dbo.Subscription", "SubscriptionPlan_ID", "dbo.SubscriptionPlan");
            DropForeignKey("dbo.SubscriptionPlanProperty", "SubscriptionPlan_ID", "dbo.SubscriptionPlan");
            DropForeignKey("dbo.Subscriber", "UserId", "dbo.User");
            DropForeignKey("dbo.Keyword", "UserId", "dbo.User");
            DropForeignKey("dbo.KeywordSubscriber", "Subscriber_ID", "dbo.Subscriber");
            DropForeignKey("dbo.KeywordSubscriber", "Keyword_ID", "dbo.Keyword");
            DropForeignKey("dbo.File", "Keyword_ID", "dbo.Keyword");
            DropForeignKey("dbo.UserRole", "UserId", "dbo.User");
            DropForeignKey("dbo.UserRole", "RoleId", "dbo.Role");
            DropForeignKey("dbo.LineItem", "Invoice_ID", "dbo.Invoice");
            DropForeignKey("dbo.Invoice", "Customer_ID", "dbo.User");
            DropForeignKey("dbo.File", "UserId", "dbo.User");
            DropForeignKey("dbo.CreditCard", "User_ID", "dbo.User");
            DropForeignKey("dbo.Address", "User_ID", "dbo.User");
            DropIndex("dbo.KeywordSubscriber", new[] { "Subscriber_ID" });
            DropIndex("dbo.KeywordSubscriber", new[] { "Keyword_ID" });
            DropIndex("dbo.UserFile", new[] { "FileId" });
            DropIndex("dbo.StripeAccount", new[] { "ManageTextUser_ID" });
            DropIndex("dbo.Message", new[] { "UserId" });
            DropIndex("dbo.Message", new[] { "CampaignId" });
            DropIndex("dbo.Message", new[] { "SubscriberId" });
            DropIndex("dbo.Message", new[] { "KeywordId" });
            DropIndex("dbo.Campaign", new[] { "UserId" });
            DropIndex("dbo.Campaign", new[] { "FileId" });
            DropIndex("dbo.Campaign", new[] { "MessageTypeId" });
            DropIndex("dbo.SubscriptionPlanProperty", new[] { "SubscriptionPlan_ID" });
            DropIndex("dbo.Subscription", new[] { "User_ID" });
            DropIndex("dbo.Subscription", new[] { "SubscriptionPlan_ID" });
            DropIndex("dbo.Subscription", new[] { "StripeId" });
            DropIndex("dbo.Keyword", new[] { "Campaign_ID" });
            DropIndex("dbo.Keyword", new[] { "UserId" });
            DropIndex("dbo.Subscriber", new[] { "UserId" });
            DropIndex("dbo.UserRole", new[] { "RoleId" });
            DropIndex("dbo.UserRole", new[] { "UserId" });
            DropIndex("dbo.LineItem", new[] { "Invoice_ID" });
            DropIndex("dbo.Invoice", new[] { "Customer_ID" });
            DropIndex("dbo.Invoice", new[] { "Paid" });
            DropIndex("dbo.Invoice", new[] { "StripeCustomerId" });
            DropIndex("dbo.Invoice", new[] { "StripeId" });
            DropIndex("dbo.File", new[] { "Message_ID" });
            DropIndex("dbo.File", new[] { "Keyword_ID" });
            DropIndex("dbo.File", new[] { "UserId" });
            DropIndex("dbo.CreditCard", new[] { "User_ID" });
            DropIndex("dbo.Address", new[] { "User_ID" });
            DropTable("dbo.KeywordSubscriber");
            DropTable("dbo.UserFile");
            DropTable("dbo.StripeAccount");
            DropTable("dbo.Error");
            DropTable("dbo.MessageType");
            DropTable("dbo.Message");
            DropTable("dbo.Campaign");
            DropTable("dbo.SubscriptionPlanProperty");
            DropTable("dbo.SubscriptionPlan");
            DropTable("dbo.Subscription");
            DropTable("dbo.Keyword");
            DropTable("dbo.Subscriber");
            DropTable("dbo.Role");
            DropTable("dbo.UserRole");
            DropTable("dbo.LineItem");
            DropTable("dbo.Invoice");
            DropTable("dbo.File");
            DropTable("dbo.CreditCard");
            DropTable("dbo.User");
            DropTable("dbo.Address");
        }
    }
}
