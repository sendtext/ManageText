namespace ManageText.Data.Migrations
{
    using ManageText.Entities.Account;
    using ManageText.Entities.Messages;
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<ManageText.Data.ManageTextContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(ManageText.Data.ManageTextContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.

            // create roles
            context.RoleSet.AddOrUpdate(r => r.Name, GenerateRoles());

            // create MessageType
            context.MessageTypeSet.AddOrUpdate(m => m.Name, GenerateMessageType());

        }


        private Role[] GenerateRoles()
        {
            Role[] _roles = new Role[]{
                    new Role(){Name="Admin" },
                    new Role(){Name="Customer" },
                    new Role(){Name="Employee" }
            };

            return _roles;
        }

        private MessageType[] GenerateMessageType()
        {
            MessageType[] _messageType = new MessageType[]{
                    new MessageType(){Name="SMS" },
                    new MessageType(){Name="MMS" }

            };

            return _messageType;
        }
    }
}
