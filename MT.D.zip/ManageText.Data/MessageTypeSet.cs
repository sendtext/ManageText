﻿namespace ManageText.Data.Migrations
{
    internal class MessageTypeSet
    {
    }
}