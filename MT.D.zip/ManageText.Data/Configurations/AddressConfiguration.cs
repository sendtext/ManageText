﻿using ManageText.Entities.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Data.Configurations
{
   

    public class AddressConfiguration : EntityBaseConfiguration<Address>
    {
        public AddressConfiguration()
        {

            Property(r => r.CreatedBy).IsOptional().HasMaxLength(50);
            Property(r => r.CreatedDate).IsOptional();
            Property(r => r.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(r => r.UpdatedDate).IsOptional();
        }
    }
}
