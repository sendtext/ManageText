﻿using ManageText.Entities.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Entities.Messages
{
    //Master Table // MMS, SMS
    public class MessageType : IEntityBase
    {

        public MessageType()
        {
            Campaigns = new List<Campaign>();
        }
        public int ID { get; set; }
        public string Name { get; set; }
        public virtual ICollection<Campaign> Campaigns { get; set; }



        //  Customer Id details 
        //public int UserId { get; set; }
        //public virtual User User { get; set; }

    }
}
